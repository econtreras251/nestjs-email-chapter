export interface SendgridAdapterConfig {
  apiKey: string;
  fromEmail: string;
  fromName?: string;
}
